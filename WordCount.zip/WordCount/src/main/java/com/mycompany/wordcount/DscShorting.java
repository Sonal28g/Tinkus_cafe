/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordcount;

import java.util.Comparator;
import java.util.TreeMap;

/**
 *
 * @author kankane shivam
 */
public class DscShorting implements Comparator<String> {

    TreeMap<String, Integer> map = new TreeMap<>();

    public DscShorting(TreeMap<String, Integer> map) {
        this.map = map;
    }

    @Override
    public int compare(String o1, String o2) {
        if (map.get(o1) < map.get(o2)) {
            return 1;
        } else {
            return -1;
        }
    }

}
