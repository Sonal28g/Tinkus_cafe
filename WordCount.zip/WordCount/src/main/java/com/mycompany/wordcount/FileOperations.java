/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordcount;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author kanka
 */
public class FileOperations {

    public static String getFile(String filePath) throws FileNotFoundException {
        File file = new File(filePath);
        Scanner sc = new Scanner(file);
        String inputFile = "";
        while (sc.hasNext()) {
            inputFile = inputFile.concat(sc.next())+"  ";

        }
        return inputFile.toLowerCase();
    }

    public static ArrayList<Character> getSymobleList(String filePath) throws FileNotFoundException {
        ArrayList<Character> symobleList = new ArrayList<>();
        File file = new File(filePath);
        Scanner sc = new Scanner(file);
        while (sc.hasNext()) {
            String next = sc.next();
            char c = next.charAt(0);
            symobleList.add(c);

        }
        return symobleList;
    }
  
}
