/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.wordcount;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeSet;

/**
 *
 * @author shivam gupta
 */
public class WordCount {

    public static void main(String[] args) throws FileNotFoundException {
        String filePath = "S:\\wordCountFile\\aaa.txt";

        //user case1
        ArrayList<String> input = UseCaseOperation.getInputWordList(filePath);
        PrintMethod.printList(input, "Original Input Word List");

        //user case 2 
        TreeSet<String> uniqueWord = UseCaseOperation.getuniqueWordLIst(filePath);
        PrintMethod.printList(uniqueWord, "unique word list");
        
        ArrayList<String> input1 = UseCaseOperation.getReverseUniqeWord(filePath);
        PrintMethod.printList(input1, "reverse unique word list");
        
        //user case 3 
        Map<String, Integer> wordcountMap = UseCaseOperation.getWordFrequency(filePath);
        PrintMethod.printMap(wordcountMap, "word Frequency");

        //user case 4 
        Map<Character, Integer> charCoutMap = UseCaseOperation.getCharFrequency(filePath);
        PrintMethod.printMapChar(charCoutMap, "charecter frequency");

        //user case 5
        Map<String, Integer> least5 = UseCaseOperation.getLeast5word(filePath);
        PrintMethod.printMap(least5, "least 5 word");

        //user case 6
        Map<String, Integer> top5 = UseCaseOperation.getTop5Word(filePath);
        PrintMethod.printMap(top5, "top 5 word ");

        //user case 7
        Map<String, Integer> least10 = UseCaseOperation.getLeast10word(filePath);
        PrintMethod.printMap(least10, "least 10 word");

        //user case 8 
        Map<String, Integer> top10 = UseCaseOperation.getTop10word(filePath);
        PrintMethod.printMap(top10, "top 10 word");

        //user case 9
        PrintMethod.printMapChar(UseCaseOperation.getLeast5Char(filePath), "least 5 charecter");

        //user case 10
        Map<Character, Integer> top5char = UseCaseOperation.getTop5char(filePath);
        PrintMethod.printMapChar(top5char, "top 5 charecter");

        //user case 11
        PrintMethod.printMapChar(UseCaseOperation.getLeast10Char(filePath), "least 10 charecter");

        //user case 12
        PrintMethod.printMapChar(UseCaseOperation.getTop10Char(filePath), "top 10 char");
    }
}
