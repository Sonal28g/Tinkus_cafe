/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordcount;

import java.util.Collection;
import java.util.Map;

/**
 *
 * @author kanka
 */
public class PrintMethod {

    public static void printList(Collection<String> list, String message) {
        System.out.println(" ================ " + message + " ================ ");
        for (String string : list) {
            System.out.println(string);
        }
    }

    public static void printMap(Map<String, Integer> list, String message) {
        System.out.println(" ================ " + message + " ================ ");
        for (Map.Entry<String, Integer> entry : list.entrySet()) {
            String key = entry.getKey();
            Integer val = entry.getValue();
            System.out.println(key + " " + val);

        }
    }

    public static void printMapChar(Map<Character, Integer> list, String message) {
        System.out.println(" ================ " + message + " ================ ");
        for (Map.Entry<Character, Integer> entry : list.entrySet()) {
            Character key = entry.getKey();
            Integer val = entry.getValue();
            System.out.println(key + " " + val);
        }
    }
}
