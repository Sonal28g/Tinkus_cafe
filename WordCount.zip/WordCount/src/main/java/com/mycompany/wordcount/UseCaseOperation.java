/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordcount;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author kanka
 */
public class UseCaseOperation {

    public static ArrayList<String> getInputWordList(String filePath) throws FileNotFoundException {
        String symbolepath = "S:\\wordCountFile\\special.txt";
        String inputFile = FileOperations.getFile(filePath);
        String file = DataCleanig.removeSymboleFile(filePath);
        ArrayList<String> stopWords = DataCleanig.getStopWord("S:\\wordCountFile\\stop.txt");
        ArrayList<String> originalInputWordList = new ArrayList<>();
        String fileArray[] = file.split(" ");
        for (String string : fileArray) {
            originalInputWordList.add(string);
        }
        originalInputWordList.removeAll(stopWords);
        return originalInputWordList;
    }

    public static TreeSet<String> getuniqueWordLIst(String filePath) throws FileNotFoundException {
        ArrayList<String> list = getInputWordList(filePath);
        TreeSet<String> uniqueWordList = new TreeSet<>(list);
        return uniqueWordList;
    }
    
    public static ArrayList<String> getReverseUniqeWord(String filePath) throws FileNotFoundException {
        ArrayList<String> list = DataCleanig.getStopWord(filePath);
        TreeSet<String> UniqueWord = getuniqueWordLIst(filePath);
        list.clear();
        list.addAll(UniqueWord);
        Collections.reverse(list);
        return list;
    }
    
    public static Map<String, Integer> getWordFrequency(String filePath) throws FileNotFoundException {
        ArrayList<String> inputList = getInputWordList(filePath);
        TreeSet<String> uniqueList = getuniqueWordLIst(filePath);
        Map<String, Integer> wordCountMap = new TreeMap();
        for (String string : uniqueList) {
            int frequency = Collections.frequency(inputList, string);
            wordCountMap.put(string, frequency);
        }
        return wordCountMap;
    }

    public static Map<Character, Integer> getCharFrequency(String filePath) throws FileNotFoundException {
        ArrayList<Character> charList = new ArrayList<>();
        for (int i = 97; i <= 122; i++) {
            charList.add((char) i);
        }
        ArrayList<String> originalInputWordList = getInputWordList(filePath);
        String inputString = "";
        for (String string : originalInputWordList) {
            inputString = inputString.concat(string);
        }
        char inputStringArray[] = inputString.toCharArray();
        ArrayList<Character> originalCharList = new ArrayList<>();
        for (char c : inputStringArray) {
            originalCharList.add(c);
        }
        Map<Character, Integer> charFrequency = new TreeMap<>();
        for (Character character : charList) {
            int count = Collections.frequency(originalCharList, character);
            charFrequency.put(character, count);

        }
        return charFrequency;
    }

    public static Map<String, Integer> getLeast5word(String filePath) throws FileNotFoundException {
        TreeMap<String, Integer> map = new TreeMap<>();
        map = (TreeMap<String, Integer>) getWordFrequency(filePath);

        Comparator asc = new AscShorting(map);
        TreeMap<String, Integer> newMap = new TreeMap<>(asc);
        newMap.putAll(map);
        Comparator asc1 = new AscShorting(map);
        TreeMap<String, Integer> least5 = new TreeMap<>(asc1);
        Iterator<Map.Entry<String, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 5) {
            Map.Entry<String, Integer> entry = itr.next();
            least5.put(entry.getKey(), entry.getValue());
            count++;

        }
        return least5;
    }

    public static Map<String, Integer> getTop5Word(String filePath) throws FileNotFoundException {
        TreeMap<String, Integer> map = new TreeMap<>();
        map = (TreeMap<String, Integer>) getWordFrequency(filePath);
        Comparator dsc = new DscShorting(map);
        TreeMap<String, Integer> newMap = new TreeMap<>(dsc);
        newMap.putAll(map);
        Comparator dsc1 = new DscShorting(map);
        TreeMap<String, Integer> top5 = new TreeMap<>(dsc1);
        Iterator<Map.Entry<String, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 5) {
            Map.Entry<String, Integer> entry = itr.next();
            top5.put(entry.getKey(), entry.getValue());
            count++;
        }
        return top5;
    }

    public static Map<String, Integer> getLeast10word(String filePath) throws FileNotFoundException {
        TreeMap<String, Integer> map = new TreeMap<>();
        map = (TreeMap<String, Integer>) getWordFrequency(filePath);
        Comparator asc = new AscShorting(map);
        TreeMap<String, Integer> newMap = new TreeMap<>(asc);
        newMap.putAll(map);
        Comparator asc1 = new AscShorting(map);
        TreeMap<String, Integer> least10 = new TreeMap<>(asc1);
        Iterator<Map.Entry<String, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 10) {
            Map.Entry<String, Integer> next = itr.next();
            least10.put(next.getKey(), next.getValue());
            count++;
        }
        return least10;
    }

    public static Map<String, Integer> getTop10word(String filePath) throws FileNotFoundException {
        TreeMap<String, Integer> map = new TreeMap<>();
        map = (TreeMap<String, Integer>) getWordFrequency(filePath);
        Comparator dsc = new DscShorting(map);
        TreeMap<String, Integer> newMap = new TreeMap<>(dsc);
        newMap.putAll(map);
        Comparator dsc1 = new DscShorting(map);
        TreeMap<String, Integer> top10 = new TreeMap<>(dsc1);
        Iterator<Map.Entry<String, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 10) {
            Map.Entry<String, Integer> next = itr.next();
            top10.put(next.getKey(), next.getValue());
            count++;
        }
        return top10;
    }

    public static Map<Character, Integer> getLeast5Char(String filePath) throws FileNotFoundException {
        TreeMap<Character, Integer> map = new TreeMap<>();
        map = (TreeMap<Character, Integer>) getCharFrequency(filePath);
        Comparator asc = new AscShortingChar(map);
        TreeMap<Character, Integer> newMap = new TreeMap<>(asc);
        newMap.putAll(map);
        Comparator asc1 = new AscShortingChar(map);
        TreeMap<Character, Integer> least5char = new TreeMap<>(asc1);
        Iterator<Map.Entry<Character, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 5) {
            Map.Entry<Character, Integer> next = itr.next();
            least5char.put(next.getKey(), next.getValue());
            count++;
        }
        return least5char;
    }

    public static Map<Character, Integer> getTop5char(String filePath) throws FileNotFoundException {
        TreeMap<Character, Integer> map = new TreeMap<>();
        map = (TreeMap<Character, Integer>) getCharFrequency(filePath);
        Comparator dsc = new DscShortingChar(map);
        TreeMap<Character, Integer> newMap = new TreeMap<>(dsc);
        newMap.putAll(map);
        Comparator dsc1 = new DscShortingChar(map);
        TreeMap<Character, Integer> top5char = new TreeMap<>(dsc1);
        Iterator<Map.Entry<Character, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 5) {
            Map.Entry<Character, Integer> next = itr.next();
            top5char.put(next.getKey(), next.getValue());
            count++;

        }
        return top5char;
    }

    public static Map<Character, Integer> getLeast10Char(String filePath) throws FileNotFoundException {
        TreeMap<Character, Integer> map = new TreeMap<>();
        map = (TreeMap<Character, Integer>) getCharFrequency(filePath);
        Comparator asc = new AscShortingChar(map);
        TreeMap<Character, Integer> newMap = new TreeMap<>(asc);
        newMap.putAll(map);
        Comparator asc1 = new AscShortingChar(map);
        TreeMap<Character, Integer> least10 = new TreeMap<>(asc1);
        Iterator<Map.Entry<Character, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 10) {
            Map.Entry<Character, Integer> next = itr.next();
            least10.put(next.getKey(), next.getValue());
            count++;
        }

        return least10;
    }

    public static Map<Character, Integer> getTop10Char(String filePath) throws FileNotFoundException {
        TreeMap<Character, Integer> map = new TreeMap<>();
        map = (TreeMap<Character, Integer>) getCharFrequency(filePath);
        Comparator dsc = new DscShortingChar(map);
        TreeMap<Character, Integer> newMap = new TreeMap<>(dsc);
        newMap.putAll(map);
        Comparator dsc1 = new DscShortingChar(map);
        TreeMap<Character, Integer> top10Char = new TreeMap<>(dsc1);
        Iterator<Map.Entry<Character, Integer>> itr = newMap.entrySet().iterator();
        int count = 0;
        while (itr.hasNext() && count < 10) {
            Map.Entry<Character, Integer> next = itr.next();
            top10Char.put(next.getKey(), next.getValue());
            count++;

        }
        return top10Char;
    }

}
