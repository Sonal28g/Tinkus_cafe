/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordcount;

import java.util.Comparator;
import java.util.TreeMap;

/**
 *
 * @author kanka
 */
public class DscShortingChar implements Comparator<Character> {

    TreeMap<Character, Integer> map = new TreeMap<>();

    public DscShortingChar(TreeMap<Character, Integer> map) {
        this.map = map;
    }

    @Override
    public int compare(Character o1, Character o2) {
        if (map.get(o1) < map.get(o2)) {
            return 1;
        } else {
            return -1;
        }
    }

}
