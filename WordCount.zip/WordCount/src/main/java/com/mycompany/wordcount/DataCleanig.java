/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wordcount;

import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 *
 * @author kanka
 */
public class DataCleanig {

    public static String removeSymboleFile(String filePath) throws FileNotFoundException {
        String inputFile = FileOperations.getFile(filePath);
        char inputMassegeArray[] = inputFile.toCharArray();
        ArrayList<Character> inputMassegeList = new ArrayList<>();
        for (Character character : inputMassegeArray) {
            inputMassegeList.add(character);
        }
        ArrayList<Character> symboleList = FileOperations.getSymobleList("S:\\wordCountFile\\special.txt");
        inputMassegeList.removeAll(symboleList);
        String inputString = "";
        for (Character character : inputMassegeList) {
            inputString = inputString.concat(String.valueOf(character));
        }
        return inputString;
    }

    public static ArrayList<String> getStopWord(String StopawordfilePath) throws FileNotFoundException {
        String stopWordFile = FileOperations.getFile(StopawordfilePath);
        String inputFileArray[] = stopWordFile.split(" ");
        ArrayList<String> StopWordList = new ArrayList<>();
        for (String string : inputFileArray) {
            StopWordList.add(string);
        }
        return StopWordList;
    }
}
